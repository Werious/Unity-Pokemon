using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    public TextMeshProUGUI healthText;
    public Image healthBar;
    public PokemonData PokemonData;

    float lerpSpeed;

    private void Start()
    {
        
    }

    private void Update()
    {
        healthText.text = PokemonData.health + "%";

        lerpSpeed = 3f * Time.deltaTime;

        HealthBarFiller();
        ColorChanger();
    }

    void HealthBarFiller()
    {
        healthBar.fillAmount = Mathf.Lerp(healthBar.fillAmount, (float)PokemonData.health / (float)PokemonData.baseHealth, lerpSpeed);
    }

    void ColorChanger()
    {
        Color healthColor = Color.Lerp(Color.red, Color.green, (float)PokemonData.health / (float)PokemonData.baseHealth);
        healthBar.color = healthColor;
    }

    

}
