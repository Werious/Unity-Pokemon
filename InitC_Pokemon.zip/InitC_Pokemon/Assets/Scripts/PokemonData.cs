using System;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class PokemonData : MonoBehaviour
{
    [SerializeField] private string pokemonName;                                                  //Name of the Pokemon
    private enum TypesPokemon { Normal, Fire, Water, Electric, Grass, Ice, Fighting, Poison, Ground, Flying, Psychic, Bug, Rock, Ghost, Dragon, Dark, Steel, Fairy, Stellar }; //List of all possible pokemon types
    [SerializeField] private TypesPokemon _type = TypesPokemon.Grass;                             //The type of the Pokemon
    [Min(0)] public int baseHealth;                                                               //The maximum health possible and start value (PUBLIC needed in HealthBar code)
    public int health;                                                                            //The current health of the Pokemon (PUBLIC needed in HealthBar code)
    [SerializeField][Min(0)] private int attack;                                                  //The amount of damage caused to other Pokemons when attacking them (not used in this exercise)
    [SerializeField][Min(0)] private int defense;                                                 //How much the Pokemon will resist when attacked (not used in this exercise)
    [SerializeField] private int _statPoints;                                                     //The result of BaseHealth + Attack + Defense points
    [SerializeField][Min(0)] private float weight;                                                //The weight of the Pokemon
    [SerializeField] private TypesPokemon[] weakness = { TypesPokemon.Fire, TypesPokemon.Ice };   //List of all weaknesses of the Pokemon (to be set manually)
    [SerializeField] private TypesPokemon[] strength = { TypesPokemon.Fairy, TypesPokemon.Rock, TypesPokemon.Water, TypesPokemon.Grass };       //List of all strenghts of the Pokemon (to be set manually)
    [SerializeField] private int enemyAttack;                                                     //The amount of damage caused by the imaginary enemy's attack to this Pokemon
    [SerializeField] private TypesPokemon _enemyType = TypesPokemon.Ice;                          //The type of the enemy (can impact damage amount)

    public GameObject damageText;                                                                 //Prefab element for floating damage text
    public TextMeshProUGUI pokemonNameText;                                                       //TextMeshPro element to display the Pokemon Name

    //Functions required for the exercise (with few additions for visuals)

    private void Awake()
    {
        InitCurrentLife();
        InitStatsPoints();

        pokemonNameText.SetText(pokemonName);                                                     //Set the Floating Text above the cube to the chosen Pokemon Name
    }

    void Start()
    {
        DisplayName();
        DisplayType();
        DisplayLife();
        DisplayAttack();
        DisplayDefense();
        DisplayStats();
        DisplayWeight();
        DisplayWeakness();
        DisplayStrenght();
        TakeDamage(enemyAttack, _enemyType);
    }

    void Update()
    {
        CheckIfPokemonAlive();

        if(transform.localScale != new Vector3(2.3f, 2.3f, 2.3f))
        {
            transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(2.3f, 2.3f, 2.3f), 0.05f);   //Grow the Pokemon back to its original size after a click
        }
    }

    void InitCurrentLife()
    {
        health = baseHealth;
    }

    void InitStatsPoints()
    {
        _statPoints = baseHealth + attack + defense;
    }

    int GetAttackDamage()
    {
        return attack;
    }

    bool DoesTypeExistInList(TypesPokemon toCheck, TypesPokemon[] list)
    {
        foreach (TypesPokemon i in list)
        {
            if (toCheck == i)
            {
                return true;
            }
        }
        return false;
    }

    void TakeDamage(int damage, TypesPokemon enemyType)
    {
        if (DoesTypeExistInList(enemyType, weakness))
        {
            damage *= 2;
        }
        else if (DoesTypeExistInList(enemyType, strength))
        {
            damage /= 2;
        }
        if (damage > 0 && health > 0)
        {
            health -= damage;
            Debug.Log($"The Pokemon took {damage} damage points.");

            GameObject DamageTextInstance = Instantiate(damageText, transform.position + new Vector3(0, 6, 0), Quaternion.Euler(0, 0, 0));
            DamageTextInstance.transform.GetChild(0).GetComponent<TextMeshProUGUI>().SetText($"-{damage}");
        }
        DisplayLife();
    }

    void CheckIfPokemonAlive()
    {
        if (health <= 0)
        {
            health = 0;
            Debug.Log("Pokemon is KO.");
        }
        else
        {
            Debug.Log("Pokemon is still alive.");
        }
    }

    //All display functions

    public void DisplayName()
    {
        Debug.Log($"Pokemon name is {pokemonName}.");
    }

    public void DisplayType()
    {
        Debug.Log($"Pokemon type is {_type}.");
    }

    public void DisplayLife()
    {
        Debug.Log($"Pokemon current life is {health} points.");
    }

    public void DisplayAttack()
    {
        Debug.Log($"Pokemon attack is {attack} points.");
    }

    public void DisplayDefense()
    {
        Debug.Log($"Pokemon defense is {defense} points.");
    }

    public void DisplayStats()
    {
        Debug.Log($"Pokemon stats is {_statPoints} points.");
    }

    public void DisplayWeight()
    {
        Debug.Log($"Pokemon weight is {weight} kg.");
    }

    public void DisplayWeakness()
    {
        foreach (TypesPokemon i in weakness)
        {
            Debug.Log($"Pokemon is weak against type : {i}");
        }
    }

    public void DisplayStrenght()
    {
        foreach (TypesPokemon i in strength)
        {
            Debug.Log($"Pokemon is durable against type : {i}");
        }
    }

    //Some "beyond the exercise" experimentations

    public void AttackButton()
    {
        TakeDamage(enemyAttack, _enemyType);
        transform.localScale = new Vector3(1.8f,1.8f,1.8f);
    }
}
